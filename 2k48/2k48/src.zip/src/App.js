// // import React from 'react';
// // import './App.css';
// // import {Grid} from '@material-ui/core';

// // import { blue, blueGrey, deepPurple, green, lightGreen, purple } from '@material-ui/core/colors';
// // import { makeStyles } from '@material-ui/core/styles';



// // const useStyles = makeStyles(theme => ({
// //   root: {
// //     //padding: theme.spacing(12, 4),
// //     height: '100%',
// //     width: '100%',
// //     display: 'flex',
// //     flexDirection: 'column',
// //     alignItems: 'center',
// //   },
// //   canvas: {
// //     //padding: theme.spacing(12, 4),
// //     height: '100%',
// //     width: '100%',
// //     display: 'flex',
// //     flexDirection: 'column',
// //     alignItems: 'center',
// //     border: '1px solid black',
// //     borderRadius: '5px',
// //     textAlign: 'center',
// //   }
// // }));


// // //change initial board to take size as a param with default to this.state.size

// // //on 

// // /*
// // generateTable(){
// //   return this.state.leaderboard.map(row => {
// //     return <TableRow>
// //               <TableRowColumn>{row.place}</TableRowColumn>
// //               <TableRowColumn>{row.name}</TableRowColumn>
// //               <TableRowColumn>{row.score}</TableRowColumn>
// //           </TableRow>
// //     })
// // }
// // */

// // function App() {
// //   const classes = useStyles();

// //   return (
//     // <div  className="App">
//     //   <Grid container>
//     //     <Grid item xs={1}>
//     //       <button onclick=""/>
//     //     <form onsubmit="return false"> 
//     //           <input type="text" size="3" value=""/>
//     //           <input type="submit" value="Resize" onclick=""/>
//     //     </form>
//     //     </Grid>
//     //     <Grid item xs={8}>
//     //       <div className={classes.canvas}>
//     //         table
//     //       </div>
//     //     </Grid>
//     //     <Grid item xs={3}>
//     //     <Table>
//     //       <TableHeader>
//     //           <TableRow>
//     //               /*Define the headers*/
//     //           </TableRow>
//     //       </TableHeader>
//     //       <TableBody>
//     //           {this.generateRows()}
//     //       </TableBody>
//     //     </Table>
//     //     </Grid>
//     //   </Grid>
//     // </div>
// //   );
// // }

// // export default App;

// import React from "react";
// import { makeStyles } from "@material-ui/core/styles";
// import Table from "@material-ui/core/Table";
// import TableBody from "@material-ui/core/TableBody";
// import TableCell from "@material-ui/core/TableCell";
// import TableContainer from "@material-ui/core/TableContainer";
// import TableHead from "@material-ui/core/TableHead";
// import TableRow from "@material-ui/core/TableRow";
// import Paper from "@material-ui/core/Paper";
// import {Grid} from '@material-ui/core';

// const useStyles = makeStyles({
//   table: {
//     minWidth: 650,
//   },
//   tableRightBorder: {
//     borderWidth: 1,
//     borderColor: "black",
//     borderStyle: "solid",
//   }
// });

// function createData(name, calories, fat, carbs, protein) {
//   return { name, calories, fat, carbs, protein };
// }

// const rows = [
//   createData(123, 159, 6.0, 24, 4.0),
//   createData(142, 237, 9.0, 37, 4.3),
//   createData(1423, 262, 16.0, 24, 6.0),
//   createData(1512, 305, 3.7, 67, 4.3),
//   createData(144, 356, 16.0, 49, 3.9)
// ];


// export default function BasicTable() {
//   const classes = useStyles();
//   return (
//         <div  className="App">
//         <Grid container>
//           <Grid item xs={1}>
          
//           </Grid>
//           <Grid item id={'table'} xs={8}>
//           <TableContainer  component={Paper}>
//       <Table  className={classes.table} aria-label="simple table">
//         <TableHead>
//           <TableRow>
//             <TableCell
//               className={classes.tableRightBorder}
//               width="10px"
//               align="center"
//             >
//               1234
//             </TableCell>
//             <TableCell width="10px" align="center">
//               250
//             </TableCell>
//             <TableCell width="10px" align="center">
//               2048
//             </TableCell>
//             <TableCell width="10px" align="center">
//               123
//             </TableCell>
//             <TableCell width="10px" align="center">
//               200
//             </TableCell>
//           </TableRow>
//         </TableHead>
//         <TableBody>
//           {rows.map((row) => (
//             <TableRow key={row.name} className="table_row_style">
//               <TableCell width="10px" align="center">
//                 {row.name}
//               </TableCell>
//               <TableCell width="10px" align="center">
//                 {row.calories}
//               </TableCell>
//               <TableCell width="10px" align="center">
//                 {row.fat}
//               </TableCell>
//               <TableCell width="10px" align="center">
//                 {row.carbs}
//               </TableCell>
//               <TableCell width="10px" align="center">
//                 {row.protein}
//               </TableCell>
//             </TableRow>
//           ))}
//         </TableBody>
//       </Table>
//     </TableContainer>

//           </Grid>
//           <Grid item xs={3}>
//             <div>{document.getElementById('table').offsetWidth}</div>
//           </Grid>
//         </Grid>
//       </div>
//   );
// }

import React from 'react';
import ReactDOM from 'react-dom';
import Grid from '@material-ui/core/Grid';

function render() {
  //const classes = useStyles();
  return (
      <div className="App">
          <Grid container>
              <Grid item xs={1}>
              </Grid>
              <Grid item xs={8}>
              </Grid>
              <Grid item xs={3}>
              </Grid>
          </Grid>
      </div>
  );
}