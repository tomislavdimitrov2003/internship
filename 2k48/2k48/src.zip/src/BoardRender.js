import React from 'react';

function renderBoard(board, score, message) {
    return (
        <div>
            <div className="score">Score: {score}</div>
            <table border="1px solid black" border-collapse="collapse">
                {board.map((row, i) => (<Row key={i} row={row} />))}
            </table>
            <p>{message}</p>
        </div>
    );
}