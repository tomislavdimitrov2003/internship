import React from 'react';

function resizeButton() {
    return (
        <form onsubmit="return false"> 
              <input id="newSize" type="text" size="3" value=""/>
              <input type="submit" value="Resize" onclick="board.InitBoard()"/>
        </form>        
    );
}